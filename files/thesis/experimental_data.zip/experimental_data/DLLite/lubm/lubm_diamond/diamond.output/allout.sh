	echo "# Benchmark:diamond"
			cat $* | grep "#" | uniq
			cat $* | grep -v "#"

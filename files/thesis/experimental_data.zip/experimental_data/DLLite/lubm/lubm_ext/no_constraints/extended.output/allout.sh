	echo "# Benchmark:extended"
			cat $* | grep "#" | uniq
			cat $* | grep -v "#"

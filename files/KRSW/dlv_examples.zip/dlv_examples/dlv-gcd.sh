#!/bin/bash
GCD="
%- Greatest Common Divisor (ASP II, slide 24) ---------------------------
divisor(D, N) :- #int(D), #int(N), #int(M), N = D * M.

cd(T,N1,N2) :- divisor(T,N1), divisor(T,N2).

-gcd(T,N1,N2) :- cd(T,N1,N2), cd(T1,N1,N2), T < T1.
gcd(T,N1,N2) :- cd(T,N1,N2), not -gcd(T,N1,N2).
%-----------------------------------------------------
"
echo -e "$GCD"
echo -e "$GCD" | dlv -N=4 --

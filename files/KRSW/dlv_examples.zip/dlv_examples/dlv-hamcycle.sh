#!/bin/bash
HAMPATH="
%- Hamiltonian Cycle (ASP II, slide 15) -----------------------------------------------------------------
inPath(X,Y) v outPath(X,Y) :- edge(X,Y).

:- inPath(X,Y), inPath(X,Y1), Y != Y1.
:- inPath(X,Y), inPath(X1,Y), X != X1.
:- node(X), not reached(X).
:- edge(X,Y), not inPath(X,Y), start(Y).
:- not start_reached.

reached(X) :- start(X).
reached(X) :- reached(Y), inPath(Y,X).
start_reached :- start(Y), inPath(Y,X).

node(a). node(b). node(c). node(d).
edge(a,b). edge(b,c). edge(d,c). edge(d,a). edge(a,d). edge(b,d). edge(a,c). edge(c,b).
start(a).
%--------------------------------------------------------------------------------------
"
echo -e "$HAMPATH"
echo -e "$HAMPATH" | dlv -nofacts --

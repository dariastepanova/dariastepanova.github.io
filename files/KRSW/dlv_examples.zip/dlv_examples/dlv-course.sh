#!/bin/bash
COURSE="
%- Course Assignment ASP II, slide 17-18 --------------------------------------------------
member(sam, cs). course(java, cs). course(ai, cs). 
member(bob, cs). course(c, cs). course(logic, cs). 
member(tom, cs). 
likes(sam, java). likes(sam, c). 
likes(bob, java). likes(bob, ai). 
likes(tom, ai). likes(tom, logic).

teach(X,Y)  :- member(X,cs), course(Y,cs), likes(X,Y), not -teach(X,Y).
-teach(X,Y) :- member(X,cs), course(Y,cs), teach(X1,Y), X1 != X. 

hascourse(X) :- member(X,cs), teach(X,Y).
:- member(X,cs), not hascourse(X).
:- teach(X,Y1), teach(X,Y2), teach(X,Y3), Y1 != Y2, Y1 != Y3, Y2 != Y3. 
%----------------------------------------------------------------------
"
echo -e "$COURSE"
echo -e "$COURSE" | dlv --

#!/bin/bash
THREECOL="
%- 3-COL (ASP II, slide 13)---------------------------
r(X) v g(X) v b(X) :- node(X).

:- edge(X,Y), r(X), r(Y).
:- edge(X,Y), g(X), g(Y).
:- edge(X,Y), b(X), b(Y).

node(a). node(b). node(c).
edge(a,b). edge(b,c). edge(a,c).
%-----------------------------------
"
echo -e "$THREECOL"
echo -e "$THREECOL" | dlv --

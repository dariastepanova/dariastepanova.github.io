#!/bin/bash
THREEUNCOL="
%- 3-UNCOL -------------------------------------------
b(X) v r(X) v g(X) :- node(X).
non_col :- r(X), r(Y), edge(X,Y).
non_col :- g(X), g(Y), edge(X,Y).
non_col :- b(X), b(Y), edge(X,Y).
b(X) :- non_col, node(X).
r(X) :- non_col, node(X).
g(X) :- non_col, node(X).

node(a). node(b). node(c). node(d).
edge(a,b). edge(a,c). edge(a,d).
edge(b,d). edge(d,c). edge(c,b).
%-----------------------------------------------------
"
echo -e "$THREEUNCOL"
echo -e "$THREEUNCOL" | dlv --

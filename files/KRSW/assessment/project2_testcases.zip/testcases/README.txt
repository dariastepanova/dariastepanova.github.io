testcase1: syntactic test
dlv -N=60 -silent -n=0 guess.dl check.dl testcases/testcase_facts.dl 

testcase2: puzzle solution test
dlv -N=60 -silent -n=0 facts.dl check.dl guess.dl testcases/testcase_facts.dl

testcase3, testcase4: testing checking part 
dlv -N=60 -silent -n=0 check.dl testcases/testcase_check1.dl
dlv -N=60 -silent -n=0 check.dl testcases/testcase_check2.dl

testcase5, testcase6: testing guessing part  
dlv -N=60 -silent -n=0 guess.dl testcases/testcase_guess1.dl
dlv -N=60 -silent -n=0 guess.dl testcases/testcase_guess2.dl

testcase7: testing both guess and check programs
dlv -N=60 -silent -n=0 guess.dl check.dl testcases/testcase_guess_check.dl

